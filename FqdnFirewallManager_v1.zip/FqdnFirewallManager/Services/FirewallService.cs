using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using FqdnFirewallManager.Models;

namespace FqdnFirewallManager.Services;

/// <summary>A user-facing failure; the message is shown in the Results log as "ERROR: ...".</summary>
public sealed class FirewallException(string message) : Exception(message);

/// <summary>
/// All firewall / Defender / scheduled-task work. The NetSecurity, Defender and ScheduledTasks
/// modules are CIM wrappers that only ship with Windows PowerShell 5.1, so each operation runs a
/// small script in a hidden powershell.exe and gets JSON back. Decision logic (validation, merge,
/// diffing, usage map) lives here in C#.
/// </summary>
public sealed class FirewallService
{
    public const string TaskName = "FqdnFirewall-Hydrate";
    public static readonly string TaskDir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "FqdnFirewall");

    private const string HostPattern = @"(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}";
    private static readonly Regex FqdnRx = new("^" + HostPattern + "$", RegexOptions.CultureInvariant);
    private static readonly Regex WildcardRx = new(@"^\*\." + HostPattern + "$", RegexOptions.CultureInvariant);
    private static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true };
    private static readonly StringComparer Ids = StringComparer.OrdinalIgnoreCase;

    // Shared PowerShell helpers (same semantics as the original script).
    private const string RulePrelude = """
        function Get-Rule([string]$Name) {
            $r = Get-NetFirewallRule -Name $Name -ErrorAction SilentlyContinue
            if (-not $r) { $r = Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue }
            if (-not $r) { throw "No firewall rule found: '$Name'" }
            if (@($r).Count -gt 1) { throw "'$Name' matches more than one rule." }
            $r
        }
        function Get-RuleKeywordIds($Rule) {
            # Property lives on the rule object (MSFT_NetFirewallRule), not the address filter.
            $fresh = Get-NetFirewallRule -Name $Rule.Name
            if (-not $fresh.CimInstanceProperties['RemoteDynamicKeywordAddresses']) {
                throw 'This rule object does not expose RemoteDynamicKeywordAddresses; refusing to read or change keywords.'
            }
            @($fresh.RemoteDynamicKeywordAddresses) | ForEach-Object { "$_" -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        }
        """;

    // ------------------------------------------------------------------ reads

    /// <summary>All rules plus all AutoResolve keywords, with "used by" computed.</summary>
    public async Task<Snapshot> GetSnapshotAsync()
    {
        const string script = """
            $r = @(Get-NetFirewallRule | ForEach-Object {
                [pscustomobject]@{
                    DisplayName = "$($_.DisplayName)"; Name = "$($_.Name)"
                    Direction = "$($_.Direction)"; Action = "$($_.Action)"; Enabled = "$($_.Enabled)"
                    KeywordIds = ((@($_.RemoteDynamicKeywordAddresses) | ForEach-Object { "$_" }) -join ',')
                } })
            $k = @(Get-NetFirewallDynamicKeywordAddress -AllAutoResolve | ForEach-Object {
                [pscustomobject]@{ Id = "$($_.Id)"; Keyword = "$($_.Keyword)"; Addresses = (@($_.Addresses) -join ', ') } })
            [pscustomobject]@{ Rules = $r; Keywords = $k } | ConvertTo-Json -Depth 4 -Compress
            """;
        var dto = await RunJsonAsync<SnapshotDto>(script) ?? new SnapshotDto();

        // id -> distinct rule display names (Get-UsageMap)
        var usage = new Dictionary<string, List<string>>(Ids);
        foreach (var rule in dto.Rules)
            foreach (var id in rule.GetKeywordIds())
            {
                if (!usage.TryGetValue(id, out var list)) usage[id] = list = new();
                if (!list.Contains(rule.DisplayName)) list.Add(rule.DisplayName);
            }

        foreach (var k in dto.Keywords)
            k.UsedBy = usage.TryGetValue(k.Id, out var users) && users.Count > 0
                ? $"{users.Count}: {string.Join("; ", users)}"
                : KeywordInfo.NotUsed;

        return new Snapshot(dto.Rules, dto.Keywords);
    }

    /// <summary>Resolve a rule by Name, then DisplayName, and read its current keyword IDs.</summary>
    public async Task<RuleDetail> GetRuleAsync(string nameOrDisplayName)
    {
        var script = $$"""
            {{RulePrelude}}
            $rule = Get-Rule {{Q(nameOrDisplayName)}}
            $ids = @(Get-RuleKeywordIds $rule)
            [pscustomobject]@{ Name = "$($rule.Name)"; DisplayName = "$($rule.DisplayName)"
                Direction = "$($rule.Direction)"; Action = "$($rule.Action)"; KeywordIds = ($ids -join ',') } | ConvertTo-Json -Compress
            """;
        return await RunJsonAsync<RuleDetail>(script) ?? throw new FirewallException($"No firewall rule found: '{nameOrDisplayName}'");
    }

    public async Task<PrereqStatus> GetPrereqAsync()
    {
        var script = $$"""
            $o = [ordered]@{ AV = $null; Platform = '?'; PlatformOK = $false; NP = 'Unknown'; TaskInstalled = $false; TaskInfo = '' }
            try {
                $mp = Get-MpComputerStatus
                $o.AV = [bool]$mp.AntivirusEnabled
                $o.Platform = "$($mp.AMProductVersion)"
                $o.PlatformOK = ([version]$mp.AMProductVersion -ge [version]'4.18.2209.7')
            } catch { }
            try {
                $v = (Get-MpPreference).EnableNetworkProtection
                $o.NP = switch ($v) { 0 {'Disabled'} 1 {'Block'} 2 {'Audit'} default {"Unknown($v)"} }
            } catch { }
            try {
                $t = Get-ScheduledTask -TaskName {{Q(TaskName)}} -ErrorAction Stop
                $i = $t | Get-ScheduledTaskInfo
                $o.TaskInstalled = $true
                $o.TaskInfo = if ($i.LastRunTime.Year -lt 2000) { 'not run yet' } else { ('last run {0:g}, result 0x{1:X}' -f $i.LastRunTime, $i.LastTaskResult) }
            } catch { }
            [pscustomobject]$o | ConvertTo-Json -Compress
            """;
        return await RunJsonAsync<PrereqStatus>(script) ?? new PrereqStatus();
    }

    // ------------------------------------------------------------------ actions

    public async Task<PrereqStatus> CheckAsync(Action<string> log)
    {
        var p = await GetPrereqAsync();
        log($"Defender antivirus enabled: {Fmt(p.AV)}  {(p.AV == true ? "[OK]" : "[FAIL] FQDN feature needs Defender AV running")}");
        log($"Defender platform {p.Platform} (need >= 4.18.2209.7)  {(p.PlatformOK ? "[OK]" : "[FAIL]")}");
        log($"Network Protection: {p.NP}  {(p.NetworkProtectionOk ? "[OK]" : "[FAIL] must be Block or Audit")}");
        log("Manual check: encrypted DNS (DoH) can stop Windows from learning IPs. This tool cannot detect it reliably.");
        return p;
    }

    public async Task LinkAsync(string ruleName, IEnumerable<string> lines, ActionOptions opt, Action<string> log)
    {
        var names = ValidateNames(lines, opt.AllowWildcards, log);
        var rule = await GetRuleAsync(ruleName);
        if (!rule.Direction.Equals("Outbound", StringComparison.OrdinalIgnoreCase))
            log($"WARNING: rule is {rule.Direction}. Microsoft documents FQDN support for outbound rules only.");

        var existing = (await GetSnapshotAsync()).Keywords;
        var ids = new List<string>();
        foreach (var name in names)
        {
            var hit = existing.FirstOrDefault(k => k.Keyword.Equals(name, StringComparison.OrdinalIgnoreCase));
            if (hit is not null) { log($"Keyword exists: {name}  {hit.Id}"); ids.Add(hit.Id); continue; }

            var id = Guid.NewGuid().ToString("B");
            if (opt.Preview) log($"[preview] would create keyword: {name}");
            else
            {
                await RunAsync($"New-NetFirewallDynamicKeywordAddress -Id {Q(id)} -Keyword {Q(name)} -AutoResolve $true | Out-Null");
                log($"Created keyword: {name}  {id}");
            }
            ids.Add(id);
        }

        var final = opt.Replace ? ids : rule.GetKeywordIds().Concat(ids).Distinct(Ids).ToList();
        if (opt.Preview) { log($"[preview] would set {final.Count} keyword(s) on '{rule.DisplayName}'."); return; }

        await SetRuleKeywordsAsync(rule.Name, final);
        var back = (await GetRuleAsync(rule.Name)).GetKeywordIds().ToHashSet(Ids);
        var missing = ids.Count(i => !back.Contains(i));
        log(missing == 0
            ? $"Linked and verified on '{rule.DisplayName}'."
            : $"WARNING: set command ran but read-back is missing {missing} keyword(s). Verify in firewall manually.");
        log("IPs appear after an app performs a DNS lookup for the name (use Hydrate).");
    }

    public async Task UnlinkAsync(string ruleName, IEnumerable<string> lines, ActionOptions opt, Action<string> log)
    {
        var names = ValidateNames(lines, opt.AllowWildcards, log).ToHashSet(StringComparer.Ordinal);
        var rule = await GetRuleAsync(ruleName);
        var kw = (await GetSnapshotAsync()).Keywords.Where(k => names.Contains(k.Keyword.ToLowerInvariant())).ToList();
        if (kw.Count == 0) throw new FirewallException("None of those names exist as keywords.");

        var rm = kw.Select(k => k.Id).ToHashSet(Ids);
        var keep = rule.GetKeywordIds().Where(i => !rm.Contains(i)).ToList();
        if (opt.Preview) { log($"[preview] would unlink {rm.Count} keyword(s) from '{rule.DisplayName}'."); return; }

        await SetRuleKeywordsAsync(rule.Name, keep);
        log($"Unlinked {rm.Count} keyword(s) from '{rule.DisplayName}'.");
        if (opt.RemoveKeyword)
        {
            foreach (var id in rm) await RunAsync($"Remove-NetFirewallDynamicKeywordAddress -Id {Q(id)}");
            log("Deleted keyword object(s).");
        }
    }

    public async Task DeleteKeywordAsync(string id, bool preview, Action<string> log)
    {
        if (string.IsNullOrWhiteSpace(id)) throw new FirewallException("No keyword selected.");
        var snap = await GetSnapshotAsync();
        var kw = snap.Keywords.FirstOrDefault(k => Ids.Equals(k.Id, id))
                 ?? throw new FirewallException("That keyword no longer exists. Refresh and try again.");
        var users = snap.Rules.Where(r => r.GetKeywordIds().Contains(id, Ids)).Select(r => r.DisplayName).Distinct().ToList();

        if (preview) { log($"[preview] would delete keyword {kw.Keyword} (used by {users.Count} rule(s))."); return; }
        await RunAsync($"Remove-NetFirewallDynamicKeywordAddress -Id {Q(id)}");
        log($"Deleted keyword {kw.Keyword} (it was used by {users.Count} rule(s)).");
        if (users.Count > 0) log($"Those rules now have an unresolved/missing keyword: {string.Join("; ", users)}");
    }

    /// <summary>DNS-resolve every non-wildcard keyword so Windows learns its IPs.</summary>
    public async Task HydrateAsync(Action<string> log)
    {
        const string script = """
            $out = New-Object System.Collections.ArrayList
            $list = @(Get-NetFirewallDynamicKeywordAddress -AllAutoResolve | Where-Object { $_.Keyword -notmatch '\*' })
            if (-not $list) { [void]$out.Add('No non-wildcard keywords to resolve.') }
            foreach ($k in $list) {
                try {
                    $r = Resolve-DnsName -Name $k.Keyword -DnsOnly -ErrorAction Stop | Where-Object { $_.IPAddress }
                    [void]$out.Add(("Resolved {0} -> {1}" -f $k.Keyword, (($r.IPAddress) -join ', ')))
                } catch { [void]$out.Add("FAILED to resolve $($k.Keyword): $($_.Exception.Message)") }
            }
            ConvertTo-Json -InputObject @($out) -Compress
            """;
        foreach (var line in await RunJsonAsync<List<string>>(script) ?? new()) log(line);
    }

    public async Task SetNetworkProtectionAuditAsync(bool preview, Action<string> log)
    {
        if (preview) { log("[preview] would run: Set-MpPreference -EnableNetworkProtection AuditMode"); return; }
        var v = (await RunAsync("Set-MpPreference -EnableNetworkProtection AuditMode; (Get-MpPreference).EnableNetworkProtection")).Trim();
        log(v == "2"
            ? "Network Protection set to Audit mode."
            : $"WARNING: setting did not stick (value is {v}). Tamper protection or a policy may be overriding it.");
    }

    public async Task InstallTaskAsync(bool preview, Action<string> log)
    {
        var path = Path.Combine(TaskDir, "Hydrate.ps1");
        if (preview) { log($"[preview] would create {path} and register task '{TaskName}' (at startup, as SYSTEM)."); return; }

        var script = $$"""
            $dir  = {{Q(TaskDir)}}
            $path = Join-Path $dir 'Hydrate.ps1'
            New-Item -ItemType Directory -Force -Path $dir | Out-Null
            # SYSTEM runs this script, so lock the folder: SYSTEM + Administrators full, Users read-only
            & icacls.exe $dir /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' | Out-Null
            if ($LASTEXITCODE -ne 0) { throw "Could not lock down $dir (icacls exit $LASTEXITCODE). Task not installed." }
            $lines = @(
                '$ErrorActionPreference = "Continue"',
                '$log = Join-Path $PSScriptRoot "hydrate.log"',
                'function L($m) { Add-Content -Path $log -Value ("{0:u} {1}" -f (Get-Date), $m) }',
                'if ((Test-Path $log) -and ((Get-Item $log).Length -gt 200KB)) { Remove-Item $log -Force }',
                'Start-Sleep -Seconds 45',
                'for ($pass = 1; $pass -le 3; $pass++) {',
                '    $kw = @(Get-NetFirewallDynamicKeywordAddress -AllAutoResolve | Where-Object { $_.Keyword -notmatch "\*" })',
                '    foreach ($k in $kw) {',
                '        try { $r = Resolve-DnsName -Name $k.Keyword -DnsOnly -ErrorAction Stop | Where-Object { $_.IPAddress }; L ("pass $pass resolved $($k.Keyword) -> " + (($r.IPAddress) -join ", ")) }',
                '        catch { L ("pass $pass FAILED $($k.Keyword): $($_.Exception.Message)") }',
                '    }',
                '    if ($pass -lt 3) { Start-Sleep -Seconds 20 }',
                '}'
            )
            Set-Content -Path $path -Value $lines -Encoding UTF8
            $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}"' -f $path)
            $trg = New-ScheduledTaskTrigger -AtStartup
            $prn = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
            $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
            Register-ScheduledTask -TaskName {{Q(TaskName)}} -Action $act -Trigger $trg -Principal $prn -Settings $set -Force | Out-Null
            """;
        await RunAsync(script);
        log($"Installed startup task '{TaskName}'. It waits ~45s after boot, then resolves non-wildcard keywords (3 passes). Log: {TaskDir}\\hydrate.log");
        log("Wildcard keywords cannot be pre-resolved; they fill in when an app looks up a matching name.");
    }

    public async Task RemoveTaskAsync(bool preview, Action<string> log)
    {
        if (preview) { log($"[preview] would remove task '{TaskName}' and delete its folder."); return; }
        await RunAsync($$"""
            Unregister-ScheduledTask -TaskName {{Q(TaskName)}} -Confirm:$false -ErrorAction Stop
            Remove-Item {{Q(TaskDir)}} -Recurse -Force -ErrorAction SilentlyContinue
            """);
        log("Removed startup task and its script folder.");
    }

    // ------------------------------------------------------------------ helpers

    /// <summary>Lower-cases, trims, validates and de-duplicates FQDNs. Throws if any are invalid.</summary>
    public static List<string> ValidateNames(IEnumerable<string> lines, bool allowWildcards, Action<string> log)
    {
        var good = new List<string>();
        var bad = false;
        foreach (var raw in lines)
        {
            var x = raw.Trim().ToLowerInvariant();
            if (x.Length == 0) continue;
            if (x.Contains('*'))
            {
                if (!allowWildcards) { log($"REJECTED '{x}': wildcards are turned off (tick 'Allow wildcards')."); bad = true; continue; }
                if (!WildcardRx.IsMatch(x)) { log($"REJECTED '{x}': wildcard must look like *.example.com"); bad = true; continue; }
            }
            else if (!FqdnRx.IsMatch(x)) { log($"REJECTED '{x}': not a valid FQDN."); bad = true; continue; }
            if (!good.Contains(x)) good.Add(x);
        }
        if (bad) throw new FirewallException("Fix the rejected names and try again. Nothing was changed.");
        if (good.Count == 0) throw new FirewallException("No FQDNs entered.");
        return good;
    }

    private Task SetRuleKeywordsAsync(string ruleName, IReadOnlyCollection<string> ids) =>
        RunAsync($"Set-NetFirewallRule -Name {Q(ruleName)} -RemoteDynamicKeywordAddresses {QArray(ids)}");

    /// <summary>
    /// Embeds a value in a script without any quoting/escaping risk (handles ', smart quotes, $ etc.)
    /// by passing it as Base64 and decoding it inside PowerShell.
    /// </summary>
    private static string Q(string value) =>
        $"([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{Convert.ToBase64String(Encoding.UTF8.GetBytes(value))}')))";

    private static string QArray(IEnumerable<string> values) => "@(" + string.Join(",", values.Select(Q)) + ")";

    private static string Fmt(bool? b) => b is null ? "" : b.Value ? "True" : "False";

    private static async Task<T?> RunJsonAsync<T>(string script)
    {
        var json = await RunAsync(script);
        if (string.IsNullOrWhiteSpace(json)) return default;
        try { return JsonSerializer.Deserialize<T>(json, Json); }
        catch (JsonException ex) { throw new FirewallException($"Could not parse PowerShell output: {ex.Message}"); }
    }

    /// <summary>Runs a script in hidden Windows PowerShell 5.1 and returns stdout. Throws on error.</summary>
    private static async Task<string> RunAsync(string body)
    {
        var script =
            "$ErrorActionPreference = 'Stop'\n" +
            "$ProgressPreference = 'SilentlyContinue'\n" +
            "[Console]::OutputEncoding = [Text.Encoding]::UTF8\n" +
            // Avoid PS 5.1 serialising arrays as {\"value\":[...],\"Count\":n}
            "Remove-TypeData System.Array -ErrorAction SilentlyContinue\n" +
            "try {\n" + body + "\n} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }\n";

        var exe = Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe");
        var psi = new ProcessStartInfo(exe,
            "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " +
            Convert.ToBase64String(Encoding.Unicode.GetBytes(script)))
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };

        using var p = Process.Start(psi) ?? throw new FirewallException("Could not start powershell.exe.");
        var stdout = p.StandardOutput.ReadToEndAsync();
        var stderr = p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync();
        var output = await stdout;
        var error = (await stderr).Trim();

        if (p.ExitCode != 0)
            throw new FirewallException(error.Length > 0 ? error : $"PowerShell exited with code {p.ExitCode}.");
        return output.Trim();
    }
}
