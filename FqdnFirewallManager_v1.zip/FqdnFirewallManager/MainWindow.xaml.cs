using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using FqdnFirewallManager.Models;
using FqdnFirewallManager.Services;

namespace FqdnFirewallManager;

public partial class MainWindow : Window
{
    private readonly FirewallService _svc = new();
    private readonly ObservableCollection<FirewallRuleInfo> _rules = new();
    private readonly ObservableCollection<KeywordInfo> _keywords = new();
    private readonly ObservableCollection<KeywordInfo> _ruleKeywords = new();
    private readonly ICollectionView _rulesView;
    private readonly Button[] _allButtons;
    private bool _busy;
    private bool _taskInstalled;

    public MainWindow()
    {
        InitializeComponent();

        _rulesView = CollectionViewSource.GetDefaultView(_rules);
        _rulesView.Filter = o =>
            string.IsNullOrWhiteSpace(TxtFilter.Text) ||
            ((FirewallRuleInfo)o).DisplayName.Contains(TxtFilter.Text.Trim(), StringComparison.OrdinalIgnoreCase);

        RuleGrid.ItemsSource = _rulesView;
        KwGrid.ItemsSource = _keywords;
        RuleKwGrid.ItemsSource = _ruleKeywords;

        _allButtons = [BtnReload, BtnLink, BtnUnlink, BtnStatus, BtnAll, BtnHydrate, BtnCheck, BtnDelKw, BtnNp, BtnTask];

        Loaded += async (_, _) =>
        {
            await RunAsync("ListRules", null, LoadAllAsync);
            await RunAsync("Prereq", null, RefreshPrereqAsync, quiet: true);
        };
    }

    // ------------------------------------------------------------------ plumbing

    private ActionOptions Options => new(
        ChkPreview.IsChecked == true, ChkReplace.IsChecked == true,
        ChkRemove.IsChecked == true, ChkWild.IsChecked == true);

    private FirewallRuleInfo? SelectedRule => RuleGrid.SelectedItem as FirewallRuleInfo;

    private IEnumerable<string> FqdnLines =>
        TxtFqdn.Text.Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0);

    private void Log(string text)
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.Invoke(() => Log(text)); return; }
        TxtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");
        TxtLog.ScrollToEnd();
    }

    /// <summary>Runs one action with all buttons disabled; errors are logged, never thrown.</summary>
    private async Task RunAsync(string action, string? ruleName, Func<Task> work, bool quiet = false)
    {
        if (_busy) return;
        _busy = true;
        foreach (var b in _allButtons) b.IsEnabled = false;
        StatusText.Text = $"Running: {action}...";
        if (!quiet) Log($"> {action} {ruleName}".TrimEnd());

        try { await work(); }
        catch (Exception ex) { Log($"ERROR: {ex.Message}"); }
        finally
        {
            _busy = false;
            foreach (var b in _allButtons) b.IsEnabled = true;
            UpdateRuleGate();
            StatusText.Text = "Ready";
        }
    }

    private static bool Confirm(string text, string title, MessageBoxImage icon = MessageBoxImage.Question) =>
        MessageBox.Show(text, title, MessageBoxButton.YesNo, icon) == MessageBoxResult.Yes;

    private string? NeedRule()
    {
        var r = SelectedRule?.Name;
        if (r is null) MessageBox.Show("Select a firewall rule first.", "No rule selected");
        return r;
    }

    // ------------------------------------------------------------------ workers

    private async Task LoadAllAsync()
    {
        var snap = await _svc.GetSnapshotAsync();
        _rules.Clear();
        foreach (var r in snap.Rules) _rules.Add(r);
        ReplaceKeywords(snap.Keywords);
        Log("Loaded rules and keywords.");
    }

    private void ReplaceKeywords(IEnumerable<KeywordInfo> keywords)
    {
        _keywords.Clear();
        foreach (var k in keywords) _keywords.Add(k);
    }

    /// <summary>Equivalent of the script's 'Status' action.</summary>
    private async Task StatusAsync(string? ruleName)
    {
        _ruleKeywords.Clear();
        var snap = await _svc.GetSnapshotAsync();
        if (ruleName is not null)
        {
            var rule = await _svc.GetRuleAsync(ruleName);
            var ids = rule.GetKeywordIds();
            Log($"Rule '{rule.DisplayName}' [{rule.Direction}/{rule.Action}] has {ids.Count} keyword(s).");
            foreach (var k in snap.Keywords.Where(k => ids.Contains(k.Id, StringComparer.OrdinalIgnoreCase)))
                _ruleKeywords.Add(k);
        }
        ReplaceKeywords(snap.Keywords);
    }

    private Task StatusSelectedAsync() => RunAsync("Status", SelectedRule?.Name, () => StatusAsync(SelectedRule?.Name));

    private async Task RefreshPrereqAsync() => UpdatePrereq(await _svc.GetPrereqAsync());

    private void UpdatePrereq(PrereqStatus p)
    {
        static string Tag(bool? v) => v == true ? "[OK]" : v is null ? "[?]" : "[!]";
        LblDef.Text = $"Defender AV: {Tag(p.AV)}    Platform {p.Platform}: {Tag(p.PlatformOK)}    Network Protection: {p.NP} {Tag(p.NetworkProtectionOk)}";
        LblDef.Foreground = p.AllOk ? Brushes.DarkGreen : Brushes.Firebrick;
        BtnNp.Visibility = p.NP == "Disabled" ? Visibility.Visible : Visibility.Collapsed;
        _taskInstalled = p.TaskInstalled;
        LblTask.Text = _taskInstalled
            ? $"Startup hydrate task: installed ({p.TaskInfo})"
            : "Startup hydrate task: not installed (resolved IPs are lost on every reboot)";
        BtnTask.Content = _taskInstalled ? "Remove startup task" : "Install startup task";
    }

    /// <summary>Gray out rule-editing controls unless the selected rule is an outbound ALLOW rule.</summary>
    private void UpdateRuleGate()
    {
        var ok = true; var why = "";
        if (SelectedRule is { } r && !r.IsOutboundAllow)
        {
            ok = false;
            why = r.Action.Equals("Allow", StringComparison.OrdinalIgnoreCase) ? $"{r.Direction} rule" : $"{r.Action} rule";
        }
        BtnLink.IsEnabled = BtnUnlink.IsEnabled = ok && !_busy;
        TxtFqdn.IsEnabled = ChkReplace.IsEnabled = ChkRemove.IsEnabled = ChkWild.IsEnabled = ok;
        GrpAct.Header = ok
            ? "2. FQDNs and actions"
            : $"2. FQDNs and actions - disabled ({why}; only outbound ALLOW rules are supported)";
    }

    // ------------------------------------------------------------------ events

    private void TxtFilter_TextChanged(object sender, TextChangedEventArgs e) => _rulesView.Refresh();

    private async void RuleGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdateRuleGate();
        if (!_busy && SelectedRule is not null) await StatusSelectedAsync();
    }

    private async void BtnReload_Click(object sender, RoutedEventArgs e) => await RunAsync("ListRules", null, LoadAllAsync);

    private async void BtnCheck_Click(object sender, RoutedEventArgs e) =>
        await RunAsync("Check", null, async () => UpdatePrereq(await _svc.CheckAsync(Log)));

    private async void BtnAll_Click(object sender, RoutedEventArgs e) => await RunAsync("Status", null, () => StatusAsync(null));

    private async void BtnStatus_Click(object sender, RoutedEventArgs e) => await StatusSelectedAsync();

    private async void BtnHydrate_Click(object sender, RoutedEventArgs e) =>
        await RunAsync("Hydrate", null, async () =>
        {
            await _svc.HydrateAsync(Log);
            ReplaceKeywords((await _svc.GetSnapshotAsync()).Keywords);
        });

    private async void BtnLink_Click(object sender, RoutedEventArgs e)
    {
        if (NeedRule() is not { } rule) return;
        var lines = FqdnLines.ToList(); var opt = Options;
        await RunAsync("Link", rule, () => _svc.LinkAsync(rule, lines, opt, Log));
        await StatusSelectedAsync();
    }

    private async void BtnUnlink_Click(object sender, RoutedEventArgs e)
    {
        if (NeedRule() is not { } rule) return;
        if (!Confirm("Unlink the listed FQDNs from this rule?", "Confirm")) return;
        var lines = FqdnLines.ToList(); var opt = Options;
        await RunAsync("Unlink", rule, () => _svc.UnlinkAsync(rule, lines, opt, Log));
        await StatusSelectedAsync();
    }

    private async void BtnDelKw_Click(object sender, RoutedEventArgs e)
    {
        if (KwGrid.SelectedItem is not KeywordInfo kw)
        {
            MessageBox.Show("Select a keyword in the \"All dynamic keywords\" grid first.", "No keyword selected");
            return;
        }
        var warn = kw.IsUnused
            ? "\n\nNo rules use it."
            : $"\n\nIt is still used by: {kw.UsedBy}\nThose rules will lose this keyword.";
        if (!Confirm($"Delete keyword '{kw.Keyword}'?{warn}", "Confirm delete", MessageBoxImage.Warning)) return;

        var preview = Options.Preview;
        await RunAsync("DeleteKeyword", SelectedRule?.Name, () => _svc.DeleteKeywordAsync(kw.Id, preview, Log));
        await StatusSelectedAsync();
    }

    private async void BtnNp_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Set Network Protection to Audit mode?\n\nAudit logs would-be blocks of malicious sites without blocking anything. " +
                     "Windows needs it on (Audit or Block) to learn IPs for FQDN keywords.", "Confirm")) return;
        var preview = Options.Preview;
        await RunAsync("SetNP", null, () => _svc.SetNetworkProtectionAuditAsync(preview, Log));
        await RunAsync("Prereq", null, RefreshPrereqAsync, quiet: true);
    }

    private async void BtnTask_Click(object sender, RoutedEventArgs e)
    {
        var preview = Options.Preview;
        if (_taskInstalled)
        {
            if (!Confirm("Remove the startup hydrate task and its script folder?", "Confirm")) return;
            await RunAsync("TaskRemove", null, () => _svc.RemoveTaskAsync(preview, Log));
        }
        else
        {
            if (!Confirm("Install a scheduled task that runs at boot as SYSTEM, waits ~45s, then resolves your non-wildcard keywords so rules repopulate?" +
                         $"\n\nThe script lives in {FirewallService.TaskDir} (locked to Administrators/SYSTEM).", "Confirm")) return;
            await RunAsync("TaskInstall", null, () => _svc.InstallTaskAsync(preview, Log));
        }
        await RunAsync("Prereq", null, RefreshPrereqAsync, quiet: true);
    }
}
