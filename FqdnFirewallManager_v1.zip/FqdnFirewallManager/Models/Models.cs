namespace FqdnFirewallManager.Models;

/// <summary>A Windows Firewall rule as listed in the rules grid.</summary>
public sealed class FirewallRuleInfo
{
    public string DisplayName { get; set; } = "";
    public string Name { get; set; } = "";
    public string Direction { get; set; } = "";
    public string Action { get; set; } = "";
    public string Enabled { get; set; } = "";
    /// <summary>Comma-separated dynamic keyword IDs (RemoteDynamicKeywordAddresses).</summary>
    public string KeywordIds { get; set; } = "";

    public IReadOnlyList<string> GetKeywordIds() => SplitIds(KeywordIds);

    public bool IsOutboundAllow =>
        Action.Equals("Allow", StringComparison.OrdinalIgnoreCase) &&
        Direction.Equals("Outbound", StringComparison.OrdinalIgnoreCase);

    internal static IReadOnlyList<string> SplitIds(string? raw) =>
        (raw ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}

/// <summary>An AutoResolve dynamic keyword address (one FQDN).</summary>
public sealed class KeywordInfo
{
    public string Id { get; set; } = "";
    public string Keyword { get; set; } = "";
    public string Addresses { get; set; } = "";
    /// <summary>"(none)" or "N: Rule A; Rule B".</summary>
    public string UsedBy { get; set; } = NotUsed;
    public bool IsUnused => UsedBy == NotUsed;

    public const string NotUsed = "(none)";
}

/// <summary>Raw output of the rule/keyword snapshot script.</summary>
public sealed class SnapshotDto
{
    public List<FirewallRuleInfo> Rules { get; set; } = new();
    public List<KeywordInfo> Keywords { get; set; } = new();
}

/// <summary>Rules and keywords with "used by" already computed.</summary>
public sealed record Snapshot(IReadOnlyList<FirewallRuleInfo> Rules, IReadOnlyList<KeywordInfo> Keywords);

/// <summary>Current state of a single rule, re-read from the firewall.</summary>
public sealed class RuleDetail
{
    public string Name { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Direction { get; set; } = "";
    public string Action { get; set; } = "";
    public string KeywordIds { get; set; } = "";

    public IReadOnlyList<string> GetKeywordIds() => FirewallRuleInfo.SplitIds(KeywordIds);
}

/// <summary>Defender / Network Protection / startup task prerequisites.</summary>
public sealed class PrereqStatus
{
    public bool? AV { get; set; }
    public string Platform { get; set; } = "?";
    public bool PlatformOK { get; set; }
    public string NP { get; set; } = "Unknown";
    public bool TaskInstalled { get; set; }
    public string TaskInfo { get; set; } = "";

    public bool NetworkProtectionOk => NP is "Block" or "Audit";
    public bool AllOk => AV == true && PlatformOK && NetworkProtectionOk;
}

/// <summary>Checkbox options from the actions panel.</summary>
public sealed record ActionOptions(bool Preview, bool Replace, bool RemoveKeyword, bool AllowWildcards);
