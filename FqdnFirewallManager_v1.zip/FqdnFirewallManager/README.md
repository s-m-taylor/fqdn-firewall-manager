# FQDN Firewall Manager (C# / .NET 8 WPF)

WPF port of `FqdnFirewallGui.ps1`: links FQDNs (Windows Firewall *Dynamic Keyword Addresses* with AutoResolve) to existing outbound ALLOW rules.

## Requirements

- Windows 10/11 (or Server 2022+) with Microsoft Defender Antivirus, platform >= 4.18.2209.7
- Network Protection in Block or Audit mode (the app can switch it to Audit)
- .NET 8 SDK to build: https://dotnet.microsoft.com/download/dotnet/8.0
- Administrator rights. The manifest requests elevation, so Windows shows a UAC prompt on launch.

## Build

```powershell
cd FqdnFirewallManager
dotnet build -c Release
# output: bin\Release\net8.0-windows\FqdnFirewallManager.exe  (needs the .NET 8 Desktop Runtime)
```

## Publish one self-contained .exe (no runtime needed on the target PC)

```powershell
dotnet publish -c Release -r win-x64
# output: bin\Release\net8.0-windows\win-x64\publish\FqdnFirewallManager.exe
```

Use `-r win-arm64` for ARM devices. For a smaller exe that relies on the installed
Desktop Runtime: `dotnet publish -c Release -r win-x64 --self-contained false`.

Visual Studio 2022 (17.8+): open `FqdnFirewallManager.csproj`, then Build or Publish.

## Project layout

| File | Purpose |
|---|---|
| `FqdnFirewallManager.csproj` | .NET 8 WPF project, single-file publish settings |
| `app.manifest` | `requireAdministrator`, per-monitor DPI (replaces the script's self-elevation) |
| `App.xaml(.cs)` | Shared styles, unhandled-error dialog |
| `Models/Models.cs` | Rule, keyword, rule detail, prerequisite and option types |
| `Services/FirewallService.cs` | All firewall, Defender, DNS and scheduled-task work |
| `MainWindow.xaml(.cs)` | UI: same 4-pane layout, buttons and confirmations as the script |

## How it works

The `NetSecurity`, `Defender` and `ScheduledTasks` cmdlets are only available in Windows PowerShell 5.1,
so `FirewallService` runs each step in a hidden `powershell.exe` (`-EncodedCommand`, values passed as
Base64 so quoting can't break) and reads JSON back. Validation, merge/replace of keyword lists,
read-back checks and the "used by" map are done in C#. Every call is async, so the window never freezes.

The startup task is the same as in the script: `FqdnFirewall-Hydrate`, run as SYSTEM at boot,
script in `C:\ProgramData\FqdnFirewall` (locked with icacls), log at `hydrate.log`.

## Behaviour carried over from the script

- Link / Unlink only for outbound ALLOW rules (other rules gray out the controls)
- FQDN validation, optional `*.example.com` wildcards, nothing changes if any name is rejected
- "Preview only" for every changing action
- Link adds to or replaces the rule's keyword list, then reads it back to verify
- Unlink can also delete the keyword objects
- Unused keywords are shaded yellow; deleting a keyword warns which rules still use it
- Hydrate resolves non-wildcard keywords (`Resolve-DnsName -DnsOnly`)
- Prerequisite banner with a one-click switch to Network Protection Audit mode
